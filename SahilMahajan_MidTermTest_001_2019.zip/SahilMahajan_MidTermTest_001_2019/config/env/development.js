﻿//Development configuration options
// 1 - database name
// 2 - a secret string to sign the session identifier
module.exports = {
    db: 'mongodb://localhost/SahilMahajan-survey-db',
    sessionSecret: 'myDevelopmentSecret'
};
